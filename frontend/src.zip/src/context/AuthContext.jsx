import { createContext, useContext, useState } from "react";

const AuthContext = createContext(null);

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);

  const login = (username, password) => {
    if (username === "Admin" && password === "Admin@123") {
      setUser({ username, role: "admin" });
      return "admin";
    } else if (username === "Student" && password === "Stu@123") {
      setUser({ username, role: "student" });
      return "student";
    } else if (username === "Faculty" && password === "Fact@123") {
      setUser({ username, role: "faculty" });
      return "faculty";
    }
    return null;
  };

  const logout = () => setUser(null);

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};